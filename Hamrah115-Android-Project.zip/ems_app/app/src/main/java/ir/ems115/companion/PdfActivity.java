package ir.ems115.companion;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class PdfActivity extends Activity {
    PdfRenderer renderer; ParcelFileDescriptor pfd; int pageNo=1; ImageView image; TextView label;
    @Override public void onCreate(Bundle b) { super.onCreate(b); pageNo=getIntent().getIntExtra("page",1); build(); try { File f=new File(getCacheDir(),"protocols.pdf"); if(!f.exists()){ try(InputStream in=getAssets().open("protocols.pdf"); FileOutputStream o=new FileOutputStream(f)){ byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)o.write(buf,0,n); } } pfd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY); renderer=new PdfRenderer(pfd); showPage(); } catch(Exception e){ label.setText("باز کردن فایل اصلی ممکن نشد: "+e.getMessage()); } }
    void build(){ LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(238,243,245)); LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER); bar.setPadding(8,8,8,8); Button prev=new Button(this); prev.setText("صفحه قبل"); prev.setOnClickListener(v->{if(pageNo>1){pageNo--;showPage();}}); Button next=new Button(this); next.setText("صفحه بعد"); next.setOnClickListener(v->{if(pageNo<119){pageNo++;showPage();}}); label=new TextView(this); label.setTextColor(Color.DKGRAY); label.setGravity(Gravity.CENTER); bar.addView(prev); bar.addView(label,new LinearLayout.LayoutParams(0,-2,1)); bar.addView(next); root.addView(bar); ScrollView sc=new ScrollView(this); image=new ImageView(this); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); sc.addView(image); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); }
    void showPage(){ try { if(renderer==null)return; PdfRenderer.Page p=renderer.openPage(pageNo-1); int w=getResources().getDisplayMetrics().widthPixels; Bitmap bm=Bitmap.createBitmap(w, (int)(w*1.414),Bitmap.Config.ARGB_8888); bm.eraseColor(Color.WHITE); p.render(bm,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); image.setImageBitmap(bm); label.setText("صفحه "+pageNo+" از ۱۱۹"); p.close(); }catch(Exception e){label.setText("خطا در نمایش صفحه");} }
    @Override protected void onDestroy(){try{if(renderer!=null)renderer.close();if(pfd!=null)pfd.close();}catch(Exception ignored){}super.onDestroy();}
}
