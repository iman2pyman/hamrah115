package ir.ems115.companion;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "NativeApp");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    class Bridge {
        @JavascriptInterface public String getPages() { try (InputStream in=getAssets().open("pages.json"); ByteArrayOutputStream out=new ByteArrayOutputStream()) { byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); return out.toString("UTF-8"); } catch(Exception e) { return "[]"; } }
        @JavascriptInterface public void openPdf(int page) {
            runOnUiThread(() -> { Intent i = new Intent(MainActivity.this, PdfActivity.class); i.putExtra("page", Math.max(1, Math.min(119,page))); startActivity(i); });
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
